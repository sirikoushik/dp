package com.cg.pp.bean;

public class TransactionDetails {
	private double credit;
	private double debit;
	private int accountNumber;
	private double amount;
	public double getCredit() {
		return credit;
	}
	public void setCredit(double credit) {
		this.credit = credit;
	}
	public double getDebit() {
		return debit;
	}
	public void setDebit(double debit) {
		this.debit = debit;
	}
	public int getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(int accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "[credit=" + credit + ", debit=" + debit + ", accountNumber=" + accountNumber
				+ ", amount=" + amount + "]";
	}
	

}
